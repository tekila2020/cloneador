
const puppeteer = require('puppeteer-extra');
const Stealth = require('puppeteer-extra-plugin-stealth');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const readline = require('readline');
const URL = require('url').URL;

puppeteer.use(Stealth());

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question('Cole a URL da página que você quer clonar: ', async function(url) {
  if (!url) return console.error('URL inválida');

  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();
  await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
  await page.goto(url, { waitUntil: 'networkidle0' });

  const folder = 'clone';
  if (!fs.existsSync(folder)) fs.mkdirSync(folder);

  let index = 0;

  const resources = await page.evaluate(() => {
    const urls = [];
    document.querySelectorAll('img,script,link').forEach(el => {
      const attr = el.tagName === 'LINK' ? 'href' : 'src';
      const url = el.getAttribute(attr);
      if (url && !url.startsWith('data:')) urls.push({ tag: el.tagName, attr, url });
    });
    getComputedStyle(document.body).backgroundImage.replace(/url\("(.+?)"\)/g, (_, u) => urls.push({ tag: 'bg', attr: 'background', url: u }));
    return urls;
  });

  let html = await page.content();

  for (const r of resources) {
    try {
      let full = new URL(r.url, url).href;
      const res = await axios.get(full, { responseType: 'arraybuffer' });
      const ext = full.split('.').pop().split(/\W/)[0];
      const fname = `asset_${index++}.${ext}`;
      fs.writeFileSync(path.join(folder, fname), res.data);
      const regex = new RegExp(r.url.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g');
      html = html.replace(regex, fname);
    } catch(e){console.error('– erro', r.url, e.message);}
  }

  fs.writeFileSync(path.join(folder, 'index.html'), html);
  await browser.close();
  rl.close();
  console.log('✅ Clone pronto na pasta "clone/"');
});
